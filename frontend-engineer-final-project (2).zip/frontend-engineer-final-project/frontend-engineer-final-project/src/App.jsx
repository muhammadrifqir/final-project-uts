import React from "react";
import HomePage from "./pages/Home/Home";

function App() {
  return (
    <div>
      <h2>Covid App M Rifqi R</h2>
      <h3>Final Project Frontend Engineer</h3>
      <HomePage />
    </div>
  );
}

export default App;
